# NBodyProblem
Simple Haskell implementation of a Barnes-Hut galaxy simulator.
When I was writing this program, I was looking at n_body_problem.py - many comments were taken from here. Original file is here.